function I = TI(prob, n_classes)

n = size(prob,1);
nt = n/n_classes;
samp = 1:nt;
base = 2;

H = sum(repmat( (1/n)* (log(1/n)/log(base)) ,n_classes,1));

I = 0;
for idx = 1:n_classes
    I = I + sum(log(prob(samp,idx))./log(base));
    samp = samp+nt;
end
I = I/n - H;

return 