function [w_smlr,opt] = smlr_retrain(X,Y,params)

[N,M]    = size(Y);
N        = N/M;
Nscans_s = 1;

% lam2 -> inf : UST
% lam2 -> 0   : LASSO
% lam1 -> 0   : L2 only

% defaults
try opt.estimate_all_w; catch, opt.estimate_all_w = true; end
% try opt.estimate_all_w; catch, opt.estimate_all_w = false; end
try opt.verbose;        catch, opt.verbose = true; end
try opt.tol;            catch, opt.tol = 0.001; end

% Outer LOO-CV loop
%%%%%%%%%%%%%%%%%%%
P    = zeros(N,M);
optf = opt; optf.tol = 0.025;
       
% Standardize
Xz = (X - repmat(mean(X(:,:)),size(X,1),1)) ./ repmat(std(X(:,:)),size(X,1),1);
Xz(isnan(Xz)) = 0;

% Parameters
lam1      = params(1);
lam2      = params(2);
    
% Train
w_smlr = smlr(Xz(:,:),Y(:,:),lam1,lam2,opt);

end

