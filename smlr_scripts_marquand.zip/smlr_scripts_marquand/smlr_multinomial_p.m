function p = smlr_multinomial_p(XW, n_classes)

E = exp(XW);

if size(XW,2) == n_classes-1 % did we estimate all weight vectors?
    Z_ref = sum(E(:,1:n_classes-1),2); % Z wrt reference category
    p = [];
    for i = 1:n_classes - 1
        p(:,i) = E(:,i) ./ (1 + Z_ref);     % all other classes
    end
    p(:,n_classes) = 1 ./ (1 + Z_ref);      % reference class
elseif size(XW,2) == n_classes
    Z = sum(E,2);
    p = E ./ repmat(Z,1,size(E,2));
else
    disp ('matrix dimension does not match number of classes');
    return
end

