function [W, loglik, logpenlik, stats] = smlr(X,Y,lam1,lam2, varargin)

% Sparse multinomial logistic regression (SMLR).
% This script provides an implementation of the SMLR algorithm proposed in
% Krishnapuram et al. (2005) that is suitable for whole brain inference.
% The implementation follows the component-wise appromximation and also
% includes the modification proposed by Ryali et al. (2009) to include a
% hybrid L1 and L2 regularisation penalty. The implementation supports
% multi-class classification by using a multinomial likelihood and a
% strategy to accelerate convergence whereby zero weights are revisited 
% with a probability that decays with the number of iterations.
%
% Inputs:
% X     : input matrix (n x d)
% Y     : label matrix (n x m)
% lam1  : L1 regularisation parameter
% lam2  : L2 regularisation paramter
% opt   : options structure (see below)
%
% Outputs:
% W     : weight vectors (d x m or d x m - 1)
% stats : statistics
%
% Options:
% opt.tol           : convergence tolerance
% opt.max_sweeeps   : maximum number of passes through the weights
% opt.decay_factor  : rate at which p(revist zero weights) decays
% opt.verbose       : debugging
% opt.graph         : show weight vector during optimisation
% opt.estimate_all  : estimate all weight vectors or just m - 1
% 
% References:
% Krishnapuram et al. (2005) Sparse Multinomial Logistic Regression: Fast
% algorithms and generalization bounds. IEEE Transactions on Pattern
% Analysis and Machine Intelligence 27, p. 957
% Ryali et al. (2010) Sparse logistic regression for whole brain
% classification of fMRI data. NeuroImage 51, p. 752.
%
% Implementation: Andre Marquand

if nargin == 5 
    opt = varargin{:};
elseif nargin ~= 4    
    disp('usage: smlr (X,Y,lambda1, lambda2, [options]');
    return;
end

% globals
m = size(Y,2); % classes
d = size(X,2); % variables

% set some default parameters
try opt.tol; catch, opt.tol = 0.001; end
try opt.max_sweeps; catch, opt.max_sweeps = 500; end
try opt.decay_factor; catch, opt.decay_factor = 0.3; end
try opt.verbose; catch, opt.verbose = false; end
try opt.graph; catch, opt.graph = false; end
try
    if opt.estimate_all_w
        n_wvs = m;
    else
        n_wvs = m-1;
    end
catch
    n_wvs = m-1;
end

% do we want to use the optimised version?
if isempty(which('smlr_core'))
    use_mex = false; 
elseif nargout > 1 
    disp ('SMLR: MEX routine does not support multiple outputs, defaulting to scripted version');
    use_mex = false;
else
    use_mex = true; 
end

% initialize weights and housekeeping parameters
W = zeros(d,n_wvs);
diff = Inf;
sweep = 1;
p_revisit = ones(size(W));

stats.wasted = zeros(1,opt.max_sweeps);
stats.recovered = zeros(1,opt.max_sweeps);
stats.diffs = zeros(1,opt.max_sweeps);

% precompute some useful quantities
XW = X*W;
%XY = X'*Y;
E = exp(XW);
if n_wvs < m
    Z = sum(E,2)+1;
else
    Z = sum(E,2);
end

if use_mex
    
    disp('SMLR: Running component-wise update (MEX version) ...');
    W = smlr_core(X,Y,XW,E,Z,lam1,lam2,opt.tol,opt.max_sweeps); 
    
else
    disp('SMLR: Running component-wise update (scripted version) ...');
    
    % precompute diag(B)
    %b = -0.5*sum(X.^2)'; % diag(B), binary classification
    b = -0.5*(1-1/m)*(sum(X.^2))';
    
    % run main optimisation loop
    while sweep < opt.max_sweeps && diff > opt.tol
        W_lastsweep = W;
        
        for f = 1:d
            for w = 1:n_wvs
                if W(f,w) ~= 0 || rand <= p_revisit(f,w)
                    W_old = W(f,w);
                    
                    % Compute probabilities for this class and feature
                    %p = logistic(XW(:,w)); % two class only
                    p = E(:,w) ./ Z;
                    
                    % Compute gradient
                    g = sum((Y(:,w) - p).*X(:,f));
                    %g =(XY(f,w)-(X(:,f))'*p);  % alternative method (slower?)
                    
                    % Compute new weight vector value
                    alpha = (b(f)./(b(f)-lam2))*W_old - g./(b(f)-lam2);
                    delta = -lam1./(b(f) -lam2);
                    W_new = sign(alpha)*max([0,abs(alpha)-delta]); % soft(alpha,delta))
                    
                    % update parameters necessary to recompute the weights
                    XW(:,w) = XW(:,w) - X(:,f)*W_old + X(:,f)*W_new;
                    E_new = exp(XW(:,w));
                    Z = Z + (E_new - E(:,w));
                    E(:,w) = E_new;
                    
                    % update weight vector and statistics
                    if W_new == 0
                        if W_old == 0
                            stats.wasted(sweep) = stats.wasted(sweep)+1;
                            p_revisit(f,w) = p_revisit(f,w) * opt.decay_factor;
                        else
                            W(f,w) = W_new;
                        end
                        
                    else
                        if W_old == 0
                            stats.recovered(sweep) = stats.recovered(sweep)+1;
                        end
                        if W_old ~= W_new
                            W(f,w) = W_new;
                        end
                    end
                end
                
            end
        end
        
        if isempty(find(W(:,w), 1)) && isempty(find(W_lastsweep(:,w),1))
            disp(['Warning: no features are non-zero. lambda1 = ',num2str(lam1,'%2.2f'),' lambda2 = ',num2str(lam1,'%2.2f')]);
        end
        
        % compute differential
        diff = abs(norm(W_lastsweep - W,'fro')) ./ norm(W,'fro');
        
        % produce extra outputs
        if opt.verbose
            disp(['sweep : ',num2str(sweep),'; diff : ',num2str(diff)]);
        end
        
        if opt.graph
            plot(W)
            drawnow
            pause(0.001)
        end
        
        stats.diffs(sweep) = diff;
        sweep = sweep + 1;
    end
    
    stats.sweeps = sweep;
    
    % compute likelihood
    if nargout > 1
        loglik = sum(sum(Y(:,1:n_wvs).*XW(:,1:n_wvs),2) - log(Z));
        logpenlik = loglik - lam1*sum(sum(abs(w))) - lam2*sum(sum(w'*w));
    end
    
end
