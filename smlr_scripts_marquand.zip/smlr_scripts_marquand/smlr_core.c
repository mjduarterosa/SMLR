#include "mex.h"
#include <string.h> 
#include <math.h>  
#include <stdlib.h> 

#define DECAY_FACTOR 0.3

/*********************************************************/
/* Function to convert matlab indices to C style indices */
/* N.B: returns array indices starting at one (not zero) */
/*********************************************************/
int idx(int irow, int icol, int nrow) 
{    
    int i;
    
    i = nrow * (icol - 1) + (irow - 1);
    
    return i;
}

/*****************/
/* Sign function */
/*****************/
int sign(double v)
{
    if (v >= 0)
        return 1;
    else
        return -1;
}

/****************/
/* Max function */
/****************/
double get_max(double a, double b)
{
    if (a >= b)
        return a;
    else
        return b;
}

/**********************************************/
/* Function to extract a column from a matrix */
/**********************************************/
void mat_col(double *m, double *matrix, int icol, int nrow) 
{    
    int i,c, start_idx;
    
    start_idx = nrow * (icol - 1);
    
    c = 0;
    for (i = start_idx; i < start_idx + nrow; i++) {
        m[c] = matrix[i];
        c++;
    }

    return;
}

/******************************************/
/* Function to compute the Frobenius norm */
/******************************************/
double frob(double *M, int nrow, int ncol)
{
    int i, j;
    double norm = 0;
    
    for (i = 1; i <= nrow; i++)
        for (j = 1; j <= ncol; j++)
            norm += pow(M[idx(i,j,nrow)],2);
    
    return sqrt(norm);
}

/**********************/
/* SMLR approximation */
/**********************/
void smlr_approx(double *W, double *X, double *Y, double *XW, double *E, double *Z,
                    double lambda1, double lambda2, double tol, double max_sweeps,
                    int d, int n, int m, int n_wvs)
 {
    int f, w, i, j, sweep;
    double *W_lastsweep, *W_diff, *p_revisit, *p, *xcol, *ycol, *b;
    double W_old, W_new, E_new, g, r, s, alpha, delta, diff;
 
    /* Allocate space */
    W_diff = mxCalloc(m * d, sizeof(double));
    W_lastsweep = mxCalloc(m * d, sizeof(double));
    p_revisit = mxCalloc(m * d, sizeof(double));
    p = mxCalloc(n, sizeof(double));  /* only need p for one class at a time */
    b = mxCalloc(d, sizeof(double));
    xcol = mxCalloc(n, sizeof(double));
    ycol = mxCalloc(n, sizeof(double));
    
    /* precompute b (could move this outside the C script) */
    for (i = 1; i <= d; i++) {
        s = 0;
        for (j = 1; j <= n; j++)
            s += pow(X[idx(j, i, n)], 2);
        b[idx(i, 1, d)] = -0.5*(1 - 1/((double) m))*s;
    }
      
    /* Initialize house-keeping parameters */
    sweep = 1;
    diff = tol + 1;  
    for (i = 0; i < d*m; i++)
        p_revisit[i] = 1;

    while (sweep <= max_sweeps && diff > tol) {
        memcpy(W_lastsweep, W, d*n_wvs*sizeof(double));

        for (f = 1; f <= d; f++) {                 /* loop over features */
            for (w = 1; w <= n_wvs; w++) {   /* loop over weight vectors */
                W_old  = W[idx(f, w, d)];
                r = (double) rand() / (double) RAND_MAX;/* rand in [0,1] */
                
                if (W_old != 0 || r <= p_revisit[idx(f, w, d)]) {
                    
                    /* compute probabilistic predictions */
                    for (i = 1; i <= n; i++) 
                        p[idx(i, 1, n)] = E[idx(i, w, n)] / Z[idx(i, 1, n)];
                        
                    /* compute gradient */
                    mat_col(ycol, Y, w, n);
                    mat_col(xcol, X, f, n);
                    g = 0;
                    for (i = 1; i <= n; i++)
                        g += (ycol[idx(i,1,n)] - p[idx(i,1,n)]) * xcol[idx(i,1,n)];                                  
                    
                    /* compute new weight */
                    alpha = b[idx(f,1,d)] / (b[idx(f,1,d)] - lambda2)*W_old - g / (b[idx(f,1,d)] - lambda2);
                    delta = -lambda1 / (b[idx(f,1,d)] - lambda2);
                    W_new = ((double) sign(alpha)) * get_max(0,fabs(alpha) - delta);
                    
                    /* update parameters */
                     for (i = 1; i <= n; i++) {
                         XW[idx(i,w,n)] = XW[idx(i,w,n)] - X[idx(i,f,n)]*W_old + X[idx(i,f,n)]*W_new;
                         E_new = exp(XW[idx(i,w,n)]);
                         Z[idx(i,1,n)] = Z[idx(i,1,n)] + (E_new - E[idx(i,w,n)]);
                         E[idx(i,w,n)] = E_new;
                    }
                    
                    /* update weights */
                    if (W_new == 0) {
                        if (W_old == 0)
                            p_revisit[idx(f,w,d)] = p_revisit[idx(f,w,d)] * DECAY_FACTOR;
                        else
                            W[idx(f,w,d)] = W_new;
                    } else {
                        if (W_old != W_new)
                            W[idx(f,w,d)] = W_new;
                    }
                }
            }
        }
        /* Compute differential */
        for (i = 1; i <= d; i++)
            for (j = 1; j <= n_wvs; j++)
                W_diff[idx(i,j,d)] = W_lastsweep[idx(i,j,d)] - W[idx(i,j,d)];
        diff = fabs(frob(W_diff,d,n_wvs)) / frob(W,d,n_wvs);
        mexPrintf("sweep : %d, diff : %2.4f\n",sweep, diff);
        
        mexEvalString("drawnow");
        sweep = sweep + 1;       
    }
      
    mxFree(W_diff);
    mxFree(W_lastsweep);
    mxFree(p_revisit);
    mxFree(p);
    mxFree(b);
    mxFree(xcol);
    mxFree(ycol);
    
    return;
}

/************************/
/* Main Execution block */
/************************/
void mexFunction(int nlhs, mxArray *plhs[], int nrhs, const mxArray *prhs[])
{
    double *W, *X, *Y, *XW_orig, *E_orig, *Z_orig, *XW, *E, *Z, *lambda1, *lambda2;
    double *tol, *max_sweeps;
    int m, d, n, n_wvs;
    
    if (nrhs == 0)
        return;
    else
        if (nrhs != 9 || nlhs != 1) {
            mexPrintf("Usage: W = smlr_core(X,Y,XW,E,Z,lambda1,lambda2,tol,max_sweeps)\n");
            mexErrMsgTxt("Incorrect number of arguments.");
            return;
        }    
    
    /* Get input matrices */
    X = mxGetPr(prhs[0]);
    Y = mxGetPr(prhs[1]);
    XW_orig = mxGetPr(prhs[2]);
    E_orig = mxGetPr(prhs[3]);
    Z_orig = mxGetPr(prhs[4]);
    lambda1 = mxGetPr(prhs[5]);
    lambda2 = mxGetPr(prhs[6]);
    tol = mxGetPr(prhs[7]);
    max_sweeps = mxGetData(prhs[8]);
    
    /* Get appropriate matrix dimensions */
    d = mxGetN(prhs[0]);
    n = mxGetM(prhs[0]);
	m = mxGetN(prhs[1]);
    n_wvs = mxGetN(prhs[2]);
    
    /* Create new data matrices (will be modified) */
    XW = mxCalloc(n*n_wvs, sizeof(double));
    E = mxCalloc(n*n_wvs, sizeof(double));
    Z = mxCalloc(n, sizeof(double));
    /* W = mxCalloc(n_wvs * d, sizeof(double)); */
    memcpy(XW, XW_orig, n*n_wvs*sizeof(double));
    memcpy(E, E_orig, n*n_wvs*sizeof(double));
    memcpy(Z, Z_orig, n*sizeof(double));

    /* Create output data structure */
    plhs[0] = mxCreateDoubleMatrix(d, n_wvs, mxREAL);
    W = mxGetPr(plhs[0]);
    
    /* Run the approximation */
    smlr_approx(W,X,Y,XW,E,Z,*lambda1,*lambda2,*tol,*max_sweeps,d,n,m,n_wvs);

    mxFree(XW);
    mxFree(E);
    mxFree(Z);
}
