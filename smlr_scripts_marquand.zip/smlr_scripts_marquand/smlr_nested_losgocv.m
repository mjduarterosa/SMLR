function [P,stats] = smlr_nested_losgocv(X,Y,opt)

[N,M]    = size(Y);
N        = N /2;
Nscans_s = 1;

% lam2 -> inf : UST
% lam2 -> 0   : LASSO
% lam1 -> 0   : L2 only

%log_params = [-5; -4; -3; -2; -1; 0; 1; 2; 3; 4; 5];
%prange     = 10.^(log_params);
log_params_l1 = -4:4;
log_params_l2 = -4:0.5:1;
prange_l1     = 10.^(log_params_l1);
prange_l2     = 10.^(log_params_l2);

% defaults
try opt.estimate_all_w; catch, opt.estimate_all_w = true; end
try opt.verbose;        catch, opt.verbose = true; end
try opt.tol;            catch, opt.tol = 0.001; end

% Outer LOO-CV loop
%%%%%%%%%%%%%%%%%%%
optf  = opt; optf.tol = 0.025;
stats = struct('valid_acc',[],'p',[],'te',[]);
try 
    matlabpool('open')
catch
    error ('Problem connecting to Matlab Parallel toobox'); 
end
parfor stest=1:N
    disp(['Test fold:', num2str(stest)]);
    
    %loop to determine the test index
    te=[]; rm=[];
    for j=1:(M*Nscans_s*N)
        if j>((stest-1)*((Nscans_s*M))) && j<((stest*(Nscans_s*M))+1)
            te=[te j];
        else
            rm=[rm j];
        end
    end
    
    % Standardize
    Xz = (X - repmat(mean(X(rm,:)),size(X,1),1)) ./ repmat(std(X(rm,:)),size(X,1),1);
    Xz(~isfinite(Xz)) = 0;
    
    % Nested LOO-CV loop
    %%%%%%%%%%%%%%%%%%%%
    correct_valid = zeros(length(prange_l1),length(prange_l2),M);
    brier_valid   = zeros(length(prange_l1),length(prange_l2),M);
    for svalid=1:N - 1
        disp(['> Validation fold:', num2str(svalid)]);
        tr=[];  va=[];
        for j=1:(M*Nscans_s*(N - 1))
            if j>((svalid-1)*((Nscans_s*M))) && j<((svalid*(Nscans_s*M))+1)
                va=[va rm(j)];
            else
                tr=[tr rm(j)];
            end
        end
        
        % loop over all parameter settings
        for i = 1:length(prange_l1)
            for j = 1:length(prange_l2)
                lam1 = prange_l1(i);
                lam2 = prange_l2(j);
                
                % train
                w_smlr = smlr(Xz(tr,:),Y(tr,:),lam1,lam2,optf);
                %[w_smlr, loglik, logpenlik, stats] =smlr(Xz(tr,:),Y(tr,:),lam1,lam2,optf);
               
                % test
                p = smlr_multinomial_p(Xz(va,:)*w_smlr, M);
                
                % compute accuracy
                for m = 1:M
                    srange = (m-1)*Nscans_s+1:m*Nscans_s;
                    c = 0;
                    for n = 1:length(srange)
                        [~, maxi] = max(p(srange(n),:));
                        if maxi == m
                            c = c+1; 
                        end
                    end
                    correct_valid(i,j,m) = correct_valid(i,j,m)+c;
                end
                brier_valid(i,j) = brier_valid(i,j) + sum(sum((eye(M) - p).^2));
            end
        end
    end
    % End nested loop
    %%%%%%%%%%%%%%%%%
    
    % compute accuracy measures
    valid_acc_allclasses = correct_valid ./ (Nscans_s * N);
    valid_acc = mean(valid_acc_allclasses,3);
    brier_valid = brier_valid ./ (Nscans_s * N);
    
    % now choose best parameter setting
    [m1 ind1] = max(valid_acc);
    [m2 ind2] = max(max(valid_acc));
    %[m1 ind1] = max(brier_valid);
    %[m2 ind2] = max(max(brier_valid));
    opti = ind1(ind2);
    optj = ind2;
    lam1 = prange_l1(opti);
    lam2 = prange_l2(optj);
       
    % train
    tr = rm;
    w_smlr= smlr(Xz(tr,:),Y(tr,:),lam1,lam2,opt);
    % test
    p = smlr_multinomial_p(Xz(te,:)*w_smlr, M);
    ptr = smlr_multinomial_p(Xz(tr,:)*w_smlr, M);
    
    stats(stest).p             = p;
    stats(stest).ptr           = ptr;
    stats(stest).tr            = tr;
    stats(stest).te            = te;
    stats(stest).w             = w_smlr;
    stats(stest).lam1          = lam1;
    stats(stest).lam2          = lam2;
    stats(stest).valid_acc     = valid_acc;
    stats(stest).valid_brier   = valid_acc;
    stats(stest).log_params_l1 = log_params_l1;
    stats(stest).log_params_l2 = log_params_l2;
end
% matlabpool('close')
P = zeros(N,M);
for f = 1:length(stats)
    P(stats(f).te,:) = stats(f).p;
end
% save([prefix,'all'],'p','lam1','lam2','w_smlr','P', 'valid_acc', 'brier_valid');
% f1 = figure;
% imagesc(valid_acc);
% saveas(f1,[prefix,'fig.fig']);
% close(f1)
% 
% f1 = figure;
% contour(brier_valid);
% saveas(f1,[prefix,'fig_brier.fig']);
% close(f1)

